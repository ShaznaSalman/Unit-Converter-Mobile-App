package nibm.hdse232.unitconvertercoursework1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class DistanceFragment: Fragment() {
    private lateinit var lblAnswerDistance: TextView
    private lateinit var txtDistance: EditText
    private lateinit var btnCalDis:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View=inflater.inflate(R.layout.fragment_distance,container,false)
        lblAnswerDistance=view.findViewById(R.id.lblAnswerDistance)
        txtDistance=view.findViewById(R.id.txtDistance)
        btnCalDis=view.findViewById(R.id.btnCalDis)

        btnCalDis.setOnClickListener(View.OnClickListener {
            val kilometers:Double=txtDistance.text.toString().toDouble()
            val meters:Double=kilometers*1000.00
            lblAnswerDistance.setText("Answer(km to m):${meters}m")
        })


        return view
    }



}