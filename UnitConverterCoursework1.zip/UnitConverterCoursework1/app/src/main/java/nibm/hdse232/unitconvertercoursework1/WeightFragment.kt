package nibm.hdse232.unitconvertercoursework1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class WeightFragment : Fragment() {

    private lateinit var lblAnswerWeight: TextView
    private lateinit var txtWeight: EditText
    private lateinit var btnCalWeight: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View=inflater.inflate(R.layout.fragment_weight,container,false)
        txtWeight=view.findViewById(R.id.txtWeight)
        lblAnswerWeight=view.findViewById(R.id.lblAnswerWeight)
        btnCalWeight=view.findViewById(R.id.btnCalWeight)
        lblAnswerWeight=view.findViewById(R.id.lblAnswerWeight)

        btnCalWeight.setOnClickListener(View.OnClickListener {
            val kilograms: Double = txtWeight.text.toString().toDouble()
            val grams: Double = kilograms * 1000.00
            lblAnswerWeight.setText("Answer(Kg to g):${grams}g")
        })
        return view

    }



}