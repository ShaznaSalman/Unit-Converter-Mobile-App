package nibm.hdse232.unitconvertercoursework1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class TemperatureFragment: Fragment() {
    private lateinit var lblAnswerTemperature: TextView
    private lateinit var txtTemperature: EditText
    private lateinit var btnCalTemp: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View=inflater.inflate(R.layout.fragment_temperature,container,false)
        lblAnswerTemperature=view.findViewById(R.id.lblAnswerTemperaure)
        txtTemperature=view.findViewById(R.id.txtTemperature)
        btnCalTemp=view.findViewById(R.id.btnCalTemp)

        btnCalTemp.setOnClickListener(View.OnClickListener {
            val farenheit:Double=txtTemperature.text.toString().toDouble()
            val celcius:Double=(farenheit-32.00)*(5.00/9.00)
            lblAnswerTemperature.setText("Answer(F to C):${celcius} C")
        })

        return view
    }


}