package nibm.hdse232.unitconvertercoursework1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {
    private lateinit var btnDistance: Button
    private lateinit var btnTemperature: Button
    private lateinit var btnWeight: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnDistance=findViewById(R.id.btnDistanceC)
        val fragmentContainer=R.id.cnsrtFragment
        btnDistance.setOnClickListener(View.OnClickListener{

            val fragmentManager: FragmentManager = supportFragmentManager
            val fragTransaction: FragmentTransaction =fragmentManager.beginTransaction()
            val fragment:DistanceFragment=DistanceFragment()
            fragTransaction.replace(fragmentContainer,fragment)
            fragTransaction.commit()
        })
        btnTemperature=findViewById(R.id.btnTemperatureC)
        btnTemperature.setOnClickListener(View.OnClickListener{

            val fragmentManager: FragmentManager =supportFragmentManager
            val fragTransaction: FragmentTransaction =fragmentManager.beginTransaction()
            val fragment:TemperatureFragment=TemperatureFragment()
            fragTransaction.replace(fragmentContainer,fragment)
            fragTransaction.commit()
        })
        btnWeight=findViewById(R.id.btnWeightC)
        btnWeight.setOnClickListener(View.OnClickListener{

            val fragmentManager: FragmentManager =supportFragmentManager
            val fragTransaction: FragmentTransaction =fragmentManager.beginTransaction()
            val fragment:WeightFragment=WeightFragment()
            fragTransaction.replace(fragmentContainer,fragment)
            fragTransaction.commit()
        })


    }
}